//TOTP - Time Based One Time Password Implementation based on TOTP Generator

const { MongoClient, ServerApiVersion } = require('mongodb');

const speakeasy  = require("speakeasy")
const crypto = require('crypto')

//Personal implementation, remove it and replace with something else.
const parse = require('./paramparse.js')
uri = parse.geturi()
//End of specific personal implementation.

const credentials = 'x509.pem'
const client = new MongoClient(uri, {
  tlsCertificateKeyFile: credentials,
  serverApi: ServerApiVersion.v1
});

//Randomly taken code, from a stackoverflow post. Modified for this purpose.
var generatekey = (
  length = 8,
  characters = 'abcdefghijklmnopqrstuvwxyz1234567890'
) =>
  Array.from(crypto.getRandomValues(new Uint32Array(length)))
    .map((x) => characters[x % characters.length])
    .join('')

//Changes the settings here.
const config =
{
        algorithm: "SHA-256",
}

//Split, once again because I forgot how otherwise.

async function TOTPGenA(req, res, next) {
    let namecheck = await client.db("general").collection("Admins").findOne({
        name: req.body.name
    })
    if(namecheck) {
        if(namecheck.TOTPKey) { //This should work, and no other situation sohuld occur, rightt ?
            const valid = totp.check(req.body.otp, namecheck.TOTPKey);

            res.locals.otp = valid
            return next();
        }
    }
}

async function TOTPGenU(req, res, next) {
    console.log("TOTP")
    let namecheck = await client.db("general").collection("Users").findOne({
        name: req.body.name
    })
    if(namecheck & req.body.otp) {
        if(namecheck.TOTPKey) { //This should work, and no other situation sohuld occur, rightt ?
            var verified = speakeasy.totp.verify({ secret: namecheck.TOTPKey, encoding: 'base32', token: req.body.otp });
            res.locals.otp = verified
            return next();
        }
    }
    else {
        res.locals.otp = false;
        return next();
    }
}

function TOTPKeyGen() {
    var secret = speakeasy.generateSecret();
    return secret
}

module.exports = {TOTPGenA, TOTPGenU, TOTPKeyGen}
